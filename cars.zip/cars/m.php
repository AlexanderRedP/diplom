<!doctype html> 
<html> <head>     
    <meta charset="utf-8">     
    <meta name="viewport" content="width=device-width, initial-scale=1.0">     
    <title>FiveMotors</title>     
    <link rel="stylesheet" href="css/cs.css"> 
    <link rel="shortcut icon" href="img/logotip.ico">
</head> 
<body>     
    <ul>         
        <li><a href="main.php" data-text="Motors">FiveMotors</a></li>         
        <li><a href="about.php" data-text="About">About</a></li>         
        <li><a href="contact.php" data-text="Contact">Contact</a></li>     
    </ul> 
</body> 
    </html> 