<html>
    <head>
<link rel="stylesheet" href="css/style.css">
<link rel="shortcut icon" href="img/logotip.ico">
<title>About</title>
</head>
<body>
    
<div><a href="m.php"><img src="img/logotip.png" alt="" style="width: 80px; height: 80px;"></a></div>

<div class="say">
            <h2 align="center">О компании</h2>
    <div class="tx4">
            Дилерский центр "FiveMotors" общей площадью 4 300 кв. м. является на сегодняшний день одним из самых крупных автосалонов в Тюменской области.
            Новый центр "FiveMotors", оснащенный самым современным оборудованием, предлагает полный спектр услуг по продаже, 
            техническому обслуживанию и ремонту автомобилей. В автосалоне также находится собственный склад запасных частей, 
            что позволяет значительно сократить время ремонта. Клиентам "FiveMotors" будут доступны выгодные программы кредитования, страхование,
             тест-драйвы и установка дополнительного оборудования. Кроме того, 
            желающие смогут обменять старый автомобиль на новый с доплатой, воспользовавшись услугой trade-in.
            В автоцентре действуют специальные акции, скидки и спецпредложения. Дилерский центр "FiveMotors" полностью 
            соответствуют высоким корпоративным стандартам, которые предъявляет всем официальным дилерам.
</div>
       <div align="center"> <img src="img/fasad.jpg" width="800px" height="500px" class="img1"></div>
</div>
    <footer>
    <div class="socialnetworks">
        <a href="#" class="facebook"> Facebook</a>
        <a href="#" class="twitter"> Twitter</a>
        <a href="#" class="google">Google+</a>
        <a href="#" class="linkedln">Linkedln</a>
        <a href="#" class="behance">Behance</a>
        <a href="#" class="dribbble">Dribbble</a>
        <a href="#" class="github">GitHub</a>
    </div>
</footer>
</body>
</html>
