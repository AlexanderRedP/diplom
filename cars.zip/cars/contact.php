<head>
<link rel="shortcut icon" href="img/logotip.ico">
<title>Contact</title>
</head>
<link rel="stylesheet" href="css/style.css">
<div><a href="m.php"><img src="img/logotip.png" alt="" style="width: 80px; height: 80px;"></a></div>
<div class="message">
        <div class="tx5">
            <h1>Обратная связь.</h1>
    <p>1600 Pennsylvania Ave NW, Washington, DC 20500, United States of America. Tel:(202) 456-1111.</p>
    </div>
    <div class="sentText">
        <form method="POST" action="connectForm.php">
                <input name="name"type="text" placeholder="*Your Name" class="inputText" size="40">
                <input name="email" type="email" placeholder="*Enter Email" class="inputEmail" size="40">
                <p><textarea name="comment" cols="87" rows="15" placeholder=" *Text Message"
                style="margin: 0px; width: 625px; height: 61px;"></textarea></p>
                <input type="button" class="load2" Value="Send Message">
           
        </form>
    </div>
</div>
<footer>
    <div class="socialnetworks">
        <a href="main.php" class="facebook"> FiveMotors</a>
        <a href="about.php" class="twitter"> About</a>
    </div>
</footer>