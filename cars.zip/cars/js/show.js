function viewDiv(){
    document.getElementById("ford").style.display = "block";
  };