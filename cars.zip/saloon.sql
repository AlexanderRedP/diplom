-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Мар 29 2022 г., 14:29
-- Версия сервера: 10.4.21-MariaDB
-- Версия PHP: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `saloon`
--

-- --------------------------------------------------------

--
-- Структура таблицы `buy`
--

CREATE TABLE `buy` (
  `name` varchar(35) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(35) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `vehicle` varchar(60) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `buy`
--

INSERT INTO `buy` (`name`, `phone`, `email`, `vehicle`) VALUES
('Andrew Led', '+9929129', 'afkjaefvsef@mail.ru', 'Mazda'),
('Afmfsnf nfasfk', '+90161212', 'saulgfayebfuk@mail.ru', 'Mazda'),
('Dmitriy Aleksandrovich', '+799983741', 'ksjefksuef@mail.ru', 'Lexus LX450'),
('', '', '', '');

-- --------------------------------------------------------

--
-- Структура таблицы `customer`
--

CREATE TABLE `customer` (
  `id_customer` int(10) NOT NULL,
  `family` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `twoname` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `passport` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `town` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `telephone` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `customer`
--

INSERT INTO `customer` (`id_customer`, `family`, `name`, `twoname`, `passport`, `town`, `address`, `telephone`) VALUES
(1, 'Olivanders', 'Oli', 'Li', 'AB313312', 'NewYork', 'Brooklyn, New York 11222, USA', '+1932932332'),
(2, 'Jigeler', 'Koster', 'Koks', 'AB23312', 'NewYork', '130 Diamond St, Brooklyn, NY 11222, USA', '+14324232');

-- --------------------------------------------------------

--
-- Структура таблицы `description`
--

CREATE TABLE `description` (
  `id_car` int(10) NOT NULL,
  `description` varchar(250) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `description`
--

INSERT INTO `description` (`id_car`, `description`) VALUES
(1, 'Toyota Supra is a two-seater premium sports coupe. Its overall dimensions are: length 4379 mm, width 1854 mm, height 1292 mm, and the wheelbase is 2470 mm. ... It is worth noting that, despite its sporty nature, the new Supra has a relatively roomy t'),
(2, 'BMW M5 is a five-seater premium business class sedan. According to the manufacturer, it combines the comfort and status of the E class with the dynamics of a real sports car. After the change of generations, its overall dimensions are: length 4965 mm');

-- --------------------------------------------------------

--
-- Структура таблицы `employee`
--

CREATE TABLE `employee` (
  `id_employeer` int(10) NOT NULL,
  `family` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `twoname` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `position` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `town` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `telephone` varchar(19) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `employee`
--

INSERT INTO `employee` (`id_employeer`, `family`, `name`, `twoname`, `position`, `town`, `address`, `telephone`) VALUES
(1, 'Williams', 'Andrew', 'Di', 'Manager', 'NewYork', '31-28 42nd St, Queens, NY 11103, USA', '+1121212'),
(2, 'Miller', 'Ice', 'Dog', 'STManager', 'NewYork', '31-28 42nd St, Queens, NY 11103, USA', '+1212134');

-- --------------------------------------------------------

--
-- Структура таблицы `manufacturer`
--

CREATE TABLE `manufacturer` (
  `id_factory` int(10) NOT NULL,
  `id_car` int(10) NOT NULL,
  `manufacturer` varchar(55) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `manufacturer`
--

INSERT INTO `manufacturer` (`id_factory`, `id_car`, `manufacturer`) VALUES
(1, 1, 'Toyota Series'),
(2, 2, 'BMW Series');

-- --------------------------------------------------------

--
-- Структура таблицы `payfrom`
--

CREATE TABLE `payfrom` (
  `id_form` int(10) NOT NULL,
  `cash` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `cashless_payments` varchar(15) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `payfrom`
--

INSERT INTO `payfrom` (`id_form`, `cash`, `cashless_payments`) VALUES
(1, 'dollar', 'dollar'),
(2, 'rubles', 'rubles');

-- --------------------------------------------------------

--
-- Структура таблицы `sales`
--

CREATE TABLE `sales` (
  `id_sale` int(12) NOT NULL,
  `id_empolyeer` int(12) NOT NULL,
  `id_car` int(10) NOT NULL,
  `id_customer` int(10) NOT NULL,
  `payment` int(10) NOT NULL,
  `date_sale` datetime(6) NOT NULL,
  `payment_form` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `id_form` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `sales`
--

INSERT INTO `sales` (`id_sale`, `id_empolyeer`, `id_car`, `id_customer`, `payment`, `date_sale`, `payment_form`, `id_form`) VALUES
(1, 1, 1, 2, 40000, '2022-01-19 15:34:04.000000', 'cash', 1),
(2, 2, 2, 1, 90000, '2022-01-20 15:34:04.000000', 'cash', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(355) COLLATE utf8_unicode_ci DEFAULT NULL,
  `login` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_confirm` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `full_name`, `login`, `email`, `password`, `password_confirm`) VALUES
(2, 'Иванов Иван Иванович', 'test', 'test@local.ru', '202cb962ac59075b964b07152d234b70', ''),
(3, 'A. NIKOLENKO', 'root', 'www@mail.ru', '4eae35f1b35977a00ebd8086c259d4c9', 'www'),
(4, 'Иван', 'hhh1', 'gluballorb@inbox.ru', '5e36941b3d856737e81516acd45edc50', 'hh');

-- --------------------------------------------------------

--
-- Структура таблицы `vehicles`
--

CREATE TABLE `vehicles` (
  `id_car` int(10) NOT NULL,
  `id_ body` int(10) NOT NULL,
  `id_engine` int(10) NOT NULL,
  `id_pts` int(10) NOT NULL,
  `brand` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `color` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `arrival_date` datetime NOT NULL,
  `release_date` datetime NOT NULL,
  `payment` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `vehicles`
--

INSERT INTO `vehicles` (`id_car`, `id_ body`, `id_engine`, `id_pts`, `brand`, `color`, `arrival_date`, `release_date`, `payment`) VALUES
(1, 232222, 234211, 343242, 'toyota', 'red', '2022-01-31 12:59:53', '2022-01-31 12:59:53', 30000),
(2, 579491, 759375, 123123, 'bmw', 'black', '2022-01-31 12:59:53', '2022-01-28 12:59:53', 566666);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id_customer`);

--
-- Индексы таблицы `description`
--
ALTER TABLE `description`
  ADD PRIMARY KEY (`id_car`);

--
-- Индексы таблицы `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id_employeer`);

--
-- Индексы таблицы `manufacturer`
--
ALTER TABLE `manufacturer`
  ADD PRIMARY KEY (`id_factory`),
  ADD KEY `id_car` (`id_car`);

--
-- Индексы таблицы `payfrom`
--
ALTER TABLE `payfrom`
  ADD PRIMARY KEY (`id_form`);

--
-- Индексы таблицы `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id_sale`),
  ADD KEY `id_empolyeer` (`id_empolyeer`,`id_car`,`id_customer`),
  ADD KEY `id_car` (`id_car`),
  ADD KEY `id_customer` (`id_customer`),
  ADD KEY `id_form` (`id_form`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`id_car`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `customer`
--
ALTER TABLE `customer`
  MODIFY `id_customer` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `employee`
--
ALTER TABLE `employee`
  MODIFY `id_employeer` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `manufacturer`
--
ALTER TABLE `manufacturer`
  MODIFY `id_factory` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `payfrom`
--
ALTER TABLE `payfrom`
  MODIFY `id_form` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `sales`
--
ALTER TABLE `sales`
  MODIFY `id_sale` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `vehicles`
--
ALTER TABLE `vehicles`
  MODIFY `id_car` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `description`
--
ALTER TABLE `description`
  ADD CONSTRAINT `description_ibfk_1` FOREIGN KEY (`id_car`) REFERENCES `vehicles` (`id_car`);

--
-- Ограничения внешнего ключа таблицы `manufacturer`
--
ALTER TABLE `manufacturer`
  ADD CONSTRAINT `manufacturer_ibfk_1` FOREIGN KEY (`id_car`) REFERENCES `vehicles` (`id_car`);

--
-- Ограничения внешнего ключа таблицы `sales`
--
ALTER TABLE `sales`
  ADD CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`id_car`) REFERENCES `vehicles` (`id_car`),
  ADD CONSTRAINT `sales_ibfk_2` FOREIGN KEY (`id_customer`) REFERENCES `customer` (`id_customer`),
  ADD CONSTRAINT `sales_ibfk_3` FOREIGN KEY (`id_empolyeer`) REFERENCES `employee` (`id_employeer`),
  ADD CONSTRAINT `sales_ibfk_4` FOREIGN KEY (`id_form`) REFERENCES `payfrom` (`id_form`);

--
-- Ограничения внешнего ключа таблицы `vehicles`
--
ALTER TABLE `vehicles`
  ADD CONSTRAINT `vehicles_ibfk_1` FOREIGN KEY (`id_car`) REFERENCES `description` (`id_car`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
